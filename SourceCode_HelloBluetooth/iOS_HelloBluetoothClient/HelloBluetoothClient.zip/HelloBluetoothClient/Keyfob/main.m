//
//  main.m
//  Keyfob
//
//  Created by Mike Foley on 12/2/11.
//  Copyright (c) 2011 Bluetooth SIG, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "KeyfobAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([KeyfobAppDelegate class]));
    }
}
